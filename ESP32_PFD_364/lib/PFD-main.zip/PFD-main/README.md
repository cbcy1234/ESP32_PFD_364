- 👋 Hi, I’m @Silicium628
- 👀 I’m interested in electronics

<!---
Silicium628/Silicium628 is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
