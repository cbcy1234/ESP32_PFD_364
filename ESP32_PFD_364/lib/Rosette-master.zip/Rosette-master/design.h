#define r 30

void hexagone(double x,double y);/// cette fonction dessine un hexagone, en prenant les coord du coin sup.gauche
void board(int lang, int image1, int image2);///cette fonction dessine, le board et la plateforme du jeu
void pion1(int x,int y);/// cette foction dessine le pion du joueur1, et prend la position de l'intersection en paramatre
void pion2(int x,int y);///cette foction dessine le pion du joueur2, et prend la position de l'intersection en paramatre

void menu(int langue, int *im1, int *im2);
 int accueil();
 void load();

