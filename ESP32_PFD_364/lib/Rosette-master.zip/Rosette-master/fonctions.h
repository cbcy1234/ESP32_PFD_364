


int jouer(int lang);/// cette fonction s'occupe des interactions avec l'utilisateur
int arrondit(float a,float reste);/// cette fonction arrondit la valeur a, elle est utile pour la position d'un pion
void recommencer();
int choiximage(int x, int y);
//int undo(info_pion ip,int player);
